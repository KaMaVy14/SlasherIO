<?php
$message = isset($_POST['username']) ? $_POST['username'] : '';

// Validate username
if (!empty($message) and strlen($message) < 730) {
    $filename = 'chat.txt';
    file_put_contents($filename, $message . "\n", FILE_APPEND | LOCK_EX);


   
} else {
    trigger_error("Message Didn't Send", E_USER_ERROR);
}
?>