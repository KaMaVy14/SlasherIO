<!DOCTYPE html>
<html>
<head>
    <title>Survey Result</title>
</head>
<body>

<h2>Survey Result</h2>

  <?php
  $username = isset($_POST['username']) ? $_POST['username'] : '';

  $all_ids = explode("\n",file_get_contents("leaderboard.txt"));
  if (!empty($username)&&!in_array($username,$all_ids)) {
      $filename = 'leaderboard.txt';
      file_put_contents($filename, $username . "\n", FILE_APPEND | LOCK_EX);

      echo "Username '$username' saved successfully!";
  } else {
      trigger_error("Username is Empty or Already Exists", E_USER_ERROR);
  }
  ?>

</body>
</html>