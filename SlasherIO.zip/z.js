
    const fileInput = document.getElementById('fileInput');
    const saveBtn = document.getElementById('saveBtn');
    const playBtn = document.getElementById('playBtn');
    const audioPlayer = document.getElementById('audioPlayer');

    let db;

    // Open IndexedDB database
    const openDB = () => {
        return new Promise((resolve, reject) => {
            const request = window.indexedDB.open('music_db', 1);

            request.onerror = () => {
                reject('Error opening database');
            };

            request.onsuccess = () => {
                db = request.result;
                resolve('Database opened successfully');
            };

            request.onupgradeneeded = (event) => {
                const db = event.target.result;
                db.createObjectStore('music_store', { keyPath: 'id' });
            };
        });
    };

    // Save file in IndexedDB
    const saveFile = (file) => {
        return new Promise((resolve, reject) => {
            const transaction = db.transaction(['music_store'], 'readwrite');
            const objectStore = transaction.objectStore('music_store');
            const request = objectStore.put({ id: 1, file: file });

            request.onsuccess = () => {
                resolve('File saved successfully');
            };

            request.onerror = () => {
                reject('Error saving file');
            };
        });
    };

    // Retrieve file from IndexedDB
    const getFile = () => {
        return new Promise((resolve, reject) => {
            const transaction = db.transaction(['music_store'], 'readonly');
            const objectStore = transaction.objectStore('music_store');
            const request = objectStore.get(1);

            request.onsuccess = () => {
                resolve(request.result.file);
            };

            request.onerror = () => {
                reject('Error retrieving file');
            };
        });
    };

    // Load audio from IndexedDB and play
    const loadAndPlayAudio = async () => {
        try {
            const file = await getFile();
            const blob = new Blob([file], { type: 'audio/mp3' });
            const url = URL.createObjectURL(blob);
            audioPlayer.src = url;
            audioPlayer.play();
        } catch (error) {
            console.error(error);
        }
    };

    // Initialize IndexedDB
    openDB().then(console.log).catch(console.error);

    // Save file when user uploads
    fileInput.addEventListener('change', async (event) => {
        const file = event.target.files[0];
        try {
            await saveFile(file);
            alert('File saved successfully');
        } catch (error) {
            console.error(error);
            alert('Error saving file');
        }
    });

    // Play audio when user clicks play button
    playBtn.addEventListener('click', loadAndPlayAudio);
