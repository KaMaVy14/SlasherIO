<!DOCTYPE html>
<html>
<head>
    <title>Survey Result</title>
</head>
<body>

<h2>Survey Result</h2>

  <?php

  $username = isset($_POST['username']) ? $_POST['username'] : '';
  if (!empty($username)) {

      $filename = 'leaderboard.txt';
      file_put_contents("leaderboard.txt", "");
      file_put_contents($filename, $username . "\n", FILE_APPEND | LOCK_EX);

      echo "Username '$username' saved successfully!";
  } else {
      echo "Error: Username is empty or already exists";
  }
  ?>

</body>
</html>