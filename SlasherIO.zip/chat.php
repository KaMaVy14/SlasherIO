<?php
$message = isset($_POST['username']) ? $_POST['username'] : '';

// Validate username
if (!empty($message)) {
    $filename = 'chat.txt';
    file_put_contents($filename, $message . "\n", FILE_APPEND | LOCK_EX);

    echo "Chat Message Sent";
} else {
    echo "Uh oh. You stopped Existing";
}
?>